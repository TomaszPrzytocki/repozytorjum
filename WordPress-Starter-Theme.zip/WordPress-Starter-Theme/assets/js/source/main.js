(function($) {

	// all Javascript code goes here

})(jQuery);
